package com.dam.xevi.bicipochamarketplace

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.dam.xevi.bicipochamarketplace.models.Bicicleta
import com.dam.xevi.bicipochamarketplace.models.components.*

class TriarBicicletaInicial : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_triar_bicicleta_inicial)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
    fun biciMontanya(view: View){
        val bicicleta = Bicicleta("Model1Muntanya", "Marca1Muntanya", 700.00,)
        bicicleta.quadre = Quadre("Marca1 alumini",0.0, "Quadre alumini marca1")
        bicicleta.color = "Negre"
        bicicleta.talla = "S"
        bicicleta.canvi = Canvi("Shimano Ultegra", 0.0, "Canvi Shimano" )
        bicicleta.frens = Freno("Shimano Ultegra", 0.0, "Conjunt de frenos Shimano Ultegra de Tambor")
        bicicleta.garantia = Garantia("Estandard", 0.0, "Un any de garantia")
        bicicleta.llantes = Llanta("Shimano Ultegra alumini", 0.0, "Llantes shimano de alumini")
        bicicleta.seient = Seient("Shimano Ultegra",0.0, "Seient Shimano de competició")
        bicicleta.pedals = Pedal("Shimano Ultegra", 0.0, "Pedals Shimano Ultegra")
        val intent = Intent(this,MenuConfiguracio::class.java)
        intent.putExtra("bicicleta", bicicleta)
        startActivity(intent)
    }
    fun biciCarretera(view: View){
        val bicicleta = Bicicleta("Model2Carretera", "Marca2Carretera", 1200.00)
        bicicleta.quadre = Quadre("Marca2 alumini",0.0, "Quadre alumini marca2")
        bicicleta.color = "Negre"
        bicicleta.talla = "S"
        bicicleta.canvi = Canvi("Shimano Ultegra", 0.0, "Canvi Shimano" )
        bicicleta.frens = Freno("Shimano Ultegra", 0.0, "Conjunt de frenos Shimano Ultegra de Tambor")
        bicicleta.garantia = Garantia("Estandard", 0.0, "Un any de garantia")
        bicicleta.llantes = Llanta("Shimano Ultegra alumini", 0.0, "Llantes shimano de alumini")
        bicicleta.seient = Seient("Shimano Ultegra",0.0, "Seient Shimano de competició")
        bicicleta.pedals = Pedal("Shimano Ultegra", 0.0, "Pedals Shimano Ultegra")
        val intent = Intent(this,MenuConfiguracio::class.java)
        intent.putExtra("bicicleta", bicicleta)
        startActivity(intent)
    }
}