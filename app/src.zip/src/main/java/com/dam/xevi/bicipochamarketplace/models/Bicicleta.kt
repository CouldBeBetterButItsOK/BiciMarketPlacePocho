package com.dam.xevi.bicipochamarketplace.models


import com.dam.xevi.bicipochamarketplace.models.components.*
import java.io.Serializable

data class Bicicleta(
    var model : String = "",
    var marca :String,
    var preu : Double,
    var talla: String? = null,
    var color: String? = null,
    var quadre: Quadre? = null,
    var canvi: Canvi? = null,
    var frens: Freno? = null,
    var llantes: Llanta? = null,
    var seient: Seient? = null,
    var pedals: Pedal? = null,
    var llum: Llum? = null,
    var garantia: Garantia? = null,
    var gps: GPS? = null,
    var portabidons: Portabidons? = null,
    var preuTotal: Double? = null
) : Serializable{
     fun calcularPreu(){
        var total = preu
        quadre?.let { total += it.preu }
        canvi?.let { total += it.preu }
        frens?.let { total += it.preu }
        llantes?.let { total += it.preu }
        gps?.let { total += it.preu }
        seient?.let { total += it.preu }
        pedals?.let { total += it.preu }
        llum?.let { total += it.preu }
        garantia?.let { total += it.preu }
        preuTotal = total
    }
}