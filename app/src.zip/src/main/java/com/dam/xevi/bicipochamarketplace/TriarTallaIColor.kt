package com.dam.xevi.bicipochamarketplace

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.dam.xevi.bicipochamarketplace.models.Bicicleta

class TriarTallaIColor : AppCompatActivity() {
    private lateinit var bicicleta: Bicicleta

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_triar_talla_icolor)

        bicicleta = intent.getSerializableExtra("bicicleta") as Bicicleta

    }
    fun acceptar(view: View){
        val colors = findViewById<RadioGroup>(R.id.colors)
        val talles = findViewById<RadioGroup>(R.id.talles)
        val colorbt = colors.checkedRadioButtonId
        val tallabt = talles.checkedRadioButtonId
        bicicleta.color = findViewById<RadioButton>(colorbt).text.toString()
        Log.d("Bicicleta", "Color actualizado: ${bicicleta.color}")
        bicicleta.talla = findViewById<RadioButton>(tallabt).text.toString()
        val resultIntent = Intent()
        resultIntent.putExtra("resultBicicleta", bicicleta)
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }
}