package com.dam.xevi.bicipochamarketplace.models.components

class Garantia (nom:String, preu:Double, description:String): Product(nom,preu,description) {
}