package com.dam.xevi.bicipochamarketplace

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.dam.xevi.bicipochamarketplace.models.Bicicleta
import com.dam.xevi.bicipochamarketplace.models.components.*

class TriarQuadreCanviFrens : AppCompatActivity() {
    private lateinit var bicicleta: Bicicleta

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_triar_quadre_canvi_frens)

        bicicleta = intent.getSerializableExtra("bicicleta") as Bicicleta

    }
    fun acceptar(view: View){
        val canvisid=  findViewById<RadioGroup>(R.id.canvis)
        val frenosid = findViewById<RadioGroup>(R.id.frenos)
        val cuadrosid = findViewById<RadioGroup>(R.id.cuadros)
        val canviid = canvisid.checkedRadioButtonId
        val frenoid = frenosid.checkedRadioButtonId
        val cuadroid = cuadrosid.checkedRadioButtonId
        val canviString = findViewById<RadioButton>(canviid).tag.toString().split("/")
        val frenoString = findViewById<RadioButton>(frenoid).tag.toString().split("/")
        val cuadroString = findViewById<RadioButton>(cuadroid).tag.toString().split("/")
        bicicleta.quadre = Quadre(cuadroString[0],cuadroString[1].toDouble(),cuadroString[2])
        bicicleta.frens = Freno(frenoString[0],frenoString[1].toDouble(),frenoString[2])
        bicicleta.canvi = Canvi(canviString[0],canviString[1].toDouble(),canviString[2])

        val resultIntent = Intent()
        resultIntent.putExtra("resultBicicleta", bicicleta)
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }
}