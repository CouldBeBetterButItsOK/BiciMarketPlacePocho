package com.dam.xevi.bicipochamarketplace.models.components

class Quadre( nom:String, preu:Double, description:String): Product(nom,preu,description) {

}