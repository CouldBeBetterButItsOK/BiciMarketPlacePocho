package com.dam.xevi.bicipochamarketplace.models.components

class Pedal( nom:String, preu:Double, description:String): Product(nom,preu,description) {
}