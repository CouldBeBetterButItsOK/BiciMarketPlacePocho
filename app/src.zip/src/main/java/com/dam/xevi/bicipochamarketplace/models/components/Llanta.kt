package com.dam.xevi.bicipochamarketplace.models.components

class Llanta( nom:String, preu:Double, description:String): Product(nom,preu,description) {
}