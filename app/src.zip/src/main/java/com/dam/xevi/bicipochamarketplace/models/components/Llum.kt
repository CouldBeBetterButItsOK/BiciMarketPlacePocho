package com.dam.xevi.bicipochamarketplace.models.components

class Llum( nom:String, preu:Double, description:String): Product(nom,preu,description) {
}